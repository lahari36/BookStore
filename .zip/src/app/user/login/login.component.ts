import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookService } from 'src/app/book.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userCredObj:any;
  constructor(private bs:BookService,private router:Router) { }
  onRegister(){
    this.router.navigateByUrl("/register")
  }
  onSubmit(formRef){
   if(formRef.valid){
    this.userCredObj=formRef.value;
    this.bs.loginUser(this.userCredObj).subscribe(
      res=>{
        if(res["message"]=="success"){
          //store username
          localStorage.setItem("token",res["signedToken"])
          localStorage.setItem("username",res["username"])

          this.router.navigateByUrl("/home");

        }
        else if(res["message"]="Invalid username"){
          alert("Invalid user")
         
          
        }
        else{
          if(res["message"]="Invalid password"){
            alert("Invalid password")
          }

          
        }
      },
      err=>{
        alert("something went wrong in login")
        console.log(err)
      }
    )
   } 
    
    
  }
  ngOnInit(): void {
  }

}